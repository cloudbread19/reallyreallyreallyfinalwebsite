
#!/usr/bin/env python

def booboo():
    return "hello"

booboo()
